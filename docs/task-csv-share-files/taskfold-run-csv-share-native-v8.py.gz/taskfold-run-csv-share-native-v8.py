import sys,subprocess,shlex
name=sys.argv[1];device={'phone':'F2ACCCB5-E5B3-426F-B962-955A113D4EF4','ipad':'ECE507C1-5704-4243-A7F7-232BF745FDB8'}[name]
cases=['testTaskCSVLargestTextShareToLocalFilesReadbackAndColdReturn']
args=['xcodebuild','test-without-building','-xctestrun','/tmp/taskfold-prepared-undo-signed-ios-build/Build/Products/Taskfold_iphonesimulator27.0-arm64.xctestrun','-destination','platform=iOS Simulator,id='+device,'-parallel-testing-enabled','NO','-collect-test-diagnostics','never','-resultBundlePath','/tmp/taskfold-csv-share-native-v8-'+name+'.xcresult']+['-only-testing:TaskfoldUITests/TaskfoldUITests/'+case for case in cases]
with open('/tmp/taskfold-csv-share-native-v8-'+name+'-ui.log','w') as log:
 log.write(shlex.join(args)+'\n');log.flush();subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
print(name,'workflow native checks passed')
