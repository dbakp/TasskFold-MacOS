import XCTest
import CryptoKit

extension TaskfoldUITests {
    @MainActor private func audioGuard() throws {
        #if os(macOS)
        let allowed = ["com.dbakp.taskfold.mac.workflowteststeameditbridge.runner", "com.dbakp.taskfold.mac.workflowteststeameditbridge.runner.xctrunner"]
        #else
        let allowed = ["com.dbakp.taskfold.workflowteststeameditbridge.uitests.xctrunner"]
        #endif
        guard allowed.contains(Bundle.main.bundleIdentifier ?? "") else { throw XCTSkip("Exact isolated audio host required") }
        continueAfterFailure = false
    }
    @MainActor private func audioPress(_ button: XCUIElement) {
        #if os(macOS)
        button.click()
        #else
        button.tap()
        #endif
    }
    @MainActor private func audioReveal(_ element: XCUIElement, _ app: XCUIApplication, towardTop: Bool = false, formIdentifier: String = "audioDraftForm", navigationTitle: String = "Audio draft") {
        let navigation = app.navigationBars[navigationTitle], form = app.collectionViews[formIdentifier]
        XCTAssertTrue(form.waitForExistence(timeout: 8), app.debugDescription)
        func viewport() -> CGRect {
            let frame = form.frame.intersection(app.windows.firstMatch.frame)
            let top = max(frame.minY, navigation.frame.maxY)
            let probe = app.staticTexts["audioFixtureLookupProbe"]
            let editorFooter = app.buttons["revokeTeamEditorFixture"]
            let footerY = formIdentifier == "taskEditorForm" && editorFooter.exists ? editorFooter.frame.minY - 8 : frame.maxY
            let bottom = min(footerY, min(frame.maxY, formIdentifier == "audioDraftForm" && probe.exists ? probe.frame.minY - 16 : frame.maxY)) - 4
            return CGRect(x: frame.minX + 4, y: top + 4, width: frame.width - 8, height: max(0, bottom - top - 4))
        }
        func visible() -> Bool {
            element.exists && element.isHittable && !element.frame.isEmpty && viewport().contains(element.frame)
        }
        for attempt in 0..<24 {
            if visible() { break }
            let area = viewport()
            XCTAssertGreaterThan(area.height, 0, app.debugDescription)
            if formIdentifier == "audioLibraryForm", element.exists, !element.frame.isEmpty,
               element.frame.height <= area.height {
                let frame = element.frame
                let margin = min(24, max(0, (area.height - frame.height) / 2))
                let shift = frame.minY < area.minY ? area.minY - frame.minY + margin : (frame.maxY > area.maxY ? area.maxY - frame.maxY - margin : 0)
                if abs(shift) > 1 {
                    let amount = max(-area.height * 0.4, min(area.height * 0.4, shift))
                    let origin = app.coordinate(withNormalizedOffset: .zero)
                    let x = area.minX + 4 - app.frame.minX, y = area.midY - app.frame.minY
                    origin.withOffset(CGVector(dx: x, dy: y)).press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: y + amount)), withVelocity: .slow, thenHoldForDuration: 0.1)
                    continue
                }
            }
            let down = element.exists && !element.frame.isEmpty ? element.frame.midY < area.midY : (attempt < 12 ? towardTop : !towardTop)
            let x = area.minX + (formIdentifier == "audioLibraryForm" ? 4 : 24) - app.frame.minX
            let from = area.minY + area.height * (down ? 0.25 : 0.8) - app.frame.minY
            let to = area.minY + area.height * (down ? 0.8 : 0.25) - app.frame.minY
            let origin = app.coordinate(withNormalizedOffset: .zero)
            origin.withOffset(CGVector(dx: x, dy: from)).press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: to)), withVelocity: .slow, thenHoldForDuration: 0.1)
        }
        if !visible() { audioScreenshot(app, "Audio control is outside the actual form viewport") }
        XCTAssertTrue(visible(), "Complete audio control must fit above native and fixture overlays: " + app.debugDescription)
    }
    @MainActor private func audioOpen(_ app: XCUIApplication, reset: Bool = true, denied: Bool = false, large: Bool = false, lostSave: Bool = false, beforeDraft: Bool = false, lostDiscard: Bool = false, lookupLock: Bool = false, prejournal: Bool = false, interrupted: Bool = false, interruptedCopy: Bool = false) {
        app.launchArguments = ["--uitesting", "--team-editor-testing", "--audio-comment-testing", "-appearance", large || denied ? "dark" : "light"]
        if reset { app.launchArguments.append("--audio-comment-reset") }
        if lostSave { app.launchArguments.append("--audio-save-lost-ack") }
        if beforeDraft { app.launchArguments.append("--audio-save-before-draft") }
        if lostDiscard { app.launchArguments.append("--audio-discard-lost-ack") }
        if lookupLock { app.launchArguments.append("--audio-save-lookup-lock") }
        if prejournal { app.launchArguments.append("--audio-save-before-journal") }
        if denied { app.launchArguments.append("--audio-comment-denied") }
        if interrupted { app.launchArguments.append("--audio-interrupted-stage-testing") }
        if interruptedCopy { app.launchArguments.append("--audio-interrupted-copy-testing") }
        app.launchArguments += ["-UIPreferredContentSizeCategoryName", large ? "UICTContentSizeCategoryAccessibilityXXXL" : "UICTContentSizeCategoryL"]
        app.launch(); app.activate()
        let open = app.buttons["audioFixtureOpen"]; XCTAssertTrue(open.waitForExistence(timeout: 15)); audioPress(open)
        XCTAssertTrue(app.navigationBars["Audio draft"].waitForExistence(timeout: 8))
        audioReveal(app.buttons["audioRecord"], app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioRecord"])], timeout: 10) == .completed)
    }
    @MainActor private func audioRecord(_ app: XCUIApplication) {
        let record = app.buttons["audioRecord"]; audioReveal(record, app); audioPress(record)
        let stop = app.buttons["audioStop"]
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND label == %@", "Stop recording"), object: stop)], timeout: 8) == .completed)
        audioPress(stop)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 10) == .completed, app.debugDescription)
    }
    @MainActor private func audioScreenshot(_ app: XCUIApplication, _ name: String) {
        #if os(macOS)
        let attachment = XCTAttachment(screenshot: app.windows.firstMatch.screenshot())
        #else
        let attachment = XCTAttachment(screenshot: app.screenshot())
        #endif
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
    @MainActor func testAudioDraftReviewSavePlaybackAndColdReturn() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app); audioRecord(app)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app); audioPress(caption)
        caption.typeText("Review the design layout and keep the original notes.")
        #if os(iOS)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        #endif
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 8) == .completed)
        audioScreenshot(app, "Reviewed and saved audio draft")
        audioPress(app.buttons["audioSaveClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-")).firstMatch
        XCTAssertTrue(saved.waitForExistence(timeout: 8)); audioReveal(saved, app); audioPress(saved)
        let restored = app.textViews["audioCaption"]; XCTAssertTrue(restored.waitForExistence(timeout: 8))
        XCTAssertEqual(restored.value as? String, "Review the design layout and keep the original notes.")
        let play = app.buttons["audioPlayback"]; audioReveal(play, app); audioPress(play)
        XCTAssertEqual(play.label, "Stop playback"); audioPress(play)
        XCTAssertEqual(play.label, "Play recording")
        audioScreenshot(app, "Restored audio recording after cold launch")
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
    }
    @MainActor func testAudioDraftSyntheticPermissionRefusalDoesNotCreateRecording() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, denied: true)
        audioPress(app.buttons["audioRecord"])
        let notice = app.staticTexts["audioNotice"]
        audioReveal(notice, app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND label CONTAINS %@", "Microphone access is off"), object: notice)], timeout: 8) == .completed)
        XCTAssertFalse(app.textViews["audioCaption"].exists)
        audioReveal(notice, app); audioScreenshot(app, "Audio draft synthetic permission refusal")
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
    }
    @MainActor func testAudioDraftDarkLargestTextControlsRemainReachable() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, large: true); audioRecord(app)
        let record = app.buttons["audioRecord"], caption = app.textViews["audioCaption"]
        audioReveal(record, app); XCTAssertEqual(record.label, "Replace recording")
        audioScreenshot(app, "Audio review controls dark largest text")
        audioReveal(caption, app)
        XCTAssertTrue(app.windows.firstMatch.frame.contains(caption.frame), app.debugDescription)
        audioScreenshot(app, "Audio caption dark largest text")
        XCTAssertTrue(app.buttons["audioSaveClose"].isHittable)
        audioPress(app.buttons["audioSaveClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
    }
    @MainActor func testAudioDraftReplacementRefusalPreservesSavedCaptionAndDuration() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app); audioRecord(app)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app); audioPress(caption); caption.typeText("Keep this saved recording")
        #if os(iOS)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        #endif
        audioPress(app.buttons["audioSaveClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false, denied: true)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-")).firstMatch
        audioReveal(saved, app); audioPress(saved)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 10) == .completed)
        let record = app.buttons["audioRecord"]; audioReveal(record, app); audioPress(record)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND label == %@", "Replace recording"), object: record)], timeout: 8) == .completed)
        let notice = app.staticTexts["audioNotice"]; audioReveal(notice, app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND (label CONTAINS %@ OR value CONTAINS %@)", "Microphone access is off", "Microphone access is off"), object: notice)], timeout: 8) == .completed)
        let duration = app.staticTexts["audioDuration"]; audioReveal(duration, app, towardTop: true)
        XCTAssertEqual(duration.value as? String, "0:01")
        let restored = app.textViews["audioCaption"]; audioReveal(restored, app)
        XCTAssertEqual(restored.value as? String, "Keep this saved recording")
        audioScreenshot(app, "Refused replacement retains saved caption and duration")
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
    }

    @MainActor func testAudioInterruptedReviewRecoversAfterColdLaunchWithoutExplicitSave() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app); audioRecord(app)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app); audioPress(caption)
        caption.typeText("Keep this interrupted review with its original audio.")
        #if os(iOS)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        #endif
        let status = app.staticTexts["audioRecoveryStatus"]; audioReveal(status, app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND (label == %@ OR value == %@)", "Recovery copy kept privately on this device.", "Recovery copy kept privately on this device."), object: status)], timeout: 10) == .completed)
        audioScreenshot(app, "Private recovery copy before interrupted review")
        app.terminate(); audioOpen(app, reset: false)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-")).firstMatch.exists)
        let recovery = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch
        XCTAssertTrue(recovery.waitForExistence(timeout: 8)); audioReveal(recovery, app); audioPress(recovery)
        let restored = app.textViews["audioCaption"]; XCTAssertTrue(restored.waitForExistence(timeout: 10))
        audioReveal(restored, app)
        XCTAssertEqual(restored.value as? String, "Keep this interrupted review with its original audio.")
        audioScreenshot(app, "Recovered unsaved review after cold launch")
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 10) == .completed)
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-")).firstMatch
        XCTAssertTrue(saved.waitForExistence(timeout: 8)); audioReveal(saved, app); audioPress(saved)
        XCTAssertTrue(app.textViews["audioCaption"].waitForExistence(timeout: 10))
        XCTAssertEqual(app.textViews["audioCaption"].value as? String, "Keep this interrupted review with its original audio.")
    }
    @MainActor func testAudioExplicitDiscardRemovesRecoveryWithoutCreatingSavedDraft() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app); audioRecord(app)
        let status = app.staticTexts["audioRecoveryStatus"]; audioReveal(status, app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND (label == %@ OR value == %@)", "Recovery copy kept privately on this device.", "Recovery copy kept privately on this device."), object: status)], timeout: 10) == .completed)
        audioPress(app.buttons["audioClose"])
        let discard = app.buttons["Discard unsaved changes"]
        XCTAssertTrue(discard.waitForExistence(timeout: 8)); audioPress(discard)
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-")).firstMatch.exists)
        XCTAssertFalse(app.textViews["audioCaption"].exists)
        audioScreenshot(app, "Explicitly discarded review stays discarded after relaunch")
    }

    @MainActor func testAudioPreparedSaveFinishesOnceAfterColdLaunchAtLargestText() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, large: true, lostSave: true); audioRecord(app)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app); audioPress(caption)
        caption.typeText("Keep this Save exactly once")
        #if os(iOS)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        #endif
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == true", "Retry save"), object: save)], timeout: 10) == .completed)
        audioScreenshot(app, "Prepared Save after lost acknowledgement")
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false, large: true)
        let pending = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch
        audioReveal(pending, app)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        audioScreenshot(app, "Finish prepared Save after cold launch at largest text")
        audioPress(pending)
        XCTAssertFalse(app.sheets["Discard this pending recording?"].exists, "Finish must not also open Discard")
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 12) == .completed)
        #if os(iOS)
        audioReveal(save, app, towardTop: true)
        #else
        audioReveal(save, app)
        #endif
        XCTAssertEqual(save.label, "Saved on this device"); XCTAssertFalse(save.isEnabled)
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false, large: true)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 1); audioPress(saved.firstMatch)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 12) == .completed)
        let restored = app.textViews["audioCaption"]
        #if os(iOS)
        audioReveal(restored, app, towardTop: true)
        #else
        audioReveal(restored, app)
        #endif
        XCTAssertEqual(restored.value as? String, "Keep this Save exactly once")
        audioScreenshot(app, "One exact saved recording after prepared Save recovery")
    }

    @MainActor func testAudioPendingDiscardSurvivesColdLaunchWithoutSavingAtLargestText() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, large: true, lostSave: true, beforeDraft: true); audioRecord(app)
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == true", "Retry save"), object: save)], timeout: 10) == .completed)
        audioPress(app.buttons["audioClose"]); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false, large: true, lostDiscard: true)
        let discard = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioDiscardPending-")).firstMatch
        audioReveal(discard, app); audioPress(discard)
        #if os(macOS)
        let confirm = app.sheets.buttons["audioConfirmDiscardPending"]
        #else
        let controls = app.sheets["Discard this pending recording?"].buttons.matching(identifier: "audioConfirmDiscardPending")
        XCTAssertTrue(controls.firstMatch.waitForExistence(timeout: 8))
        let count = controls.count
        XCTAssertTrue((1...2).contains(count), "One logical discard action expected")
        // UIKit exposes SwiftUI's action as a nested pair on this runtime.
        // Check it is one action before selecting its innermost control.
        if count == 2 {
            XCTAssertEqual(controls.element(boundBy: 0).frame, controls.element(boundBy: 1).frame)
            XCTAssertEqual(controls.element(boundBy: 0).label, controls.element(boundBy: 1).label)
        }
        let confirm = controls.element(boundBy: max(0, count - 1))
        #endif
        XCTAssertTrue(confirm.waitForExistence(timeout: 8))
        XCTAssertFalse(app.textViews["audioCaption"].exists, "Opening discard must not also resume the Save")
        audioPress(confirm)
        let pending = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch
        audioReveal(pending, app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND label CONTAINS[c] %@", "Finish discarding"), object: pending)], timeout: 12) == .completed)
        audioReveal(pending, app); audioScreenshot(app, "Discard kept after acknowledgement loss")
        audioPress(app.buttons["audioClose"]); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false, large: true)
        audioReveal(pending, app)
        XCTAssertTrue(pending.label.localizedCaseInsensitiveContains("Finish discarding"))
        audioScreenshot(app, "Finish durable discard after cold launch at largest text")
        audioPress(pending)
        XCTAssertFalse(app.sheets["Discard this pending recording?"].exists, "Finish must not also open Discard")
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: pending)], timeout: 10) == .completed)
        audioPress(app.buttons["audioClose"]); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false, large: true)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        audioScreenshot(app, "Durable discard leaves no recording after cold return")
    }
    @MainActor func testAudioPendingDiscardRefusesAlreadySavedRecording() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, lostSave: true); audioRecord(app)
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == true", "Retry save"), object: save)], timeout: 10) == .completed)
        audioPress(app.buttons["audioClose"]); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        let discard = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioDiscardPending-")).firstMatch
        audioReveal(discard, app); audioPress(discard)
        #if os(macOS)
        let confirm = app.sheets.buttons["audioConfirmDiscardPending"]
        #else
        let controls = app.sheets["Discard this pending recording?"].buttons.matching(identifier: "audioConfirmDiscardPending")
        XCTAssertTrue(controls.firstMatch.waitForExistence(timeout: 8))
        let count = controls.count
        XCTAssertTrue((1...2).contains(count), "One logical discard action expected")
        // UIKit exposes SwiftUI's action as a nested pair on this runtime.
        // Check it is one action before selecting its innermost control.
        if count == 2 {
            XCTAssertEqual(controls.element(boundBy: 0).frame, controls.element(boundBy: 1).frame)
            XCTAssertEqual(controls.element(boundBy: 0).label, controls.element(boundBy: 1).label)
        }
        let confirm = controls.element(boundBy: max(0, count - 1))
        #endif
        XCTAssertTrue(confirm.waitForExistence(timeout: 8))
        XCTAssertFalse(app.textViews["audioCaption"].exists, "Opening discard must not also resume the Save")
        audioPress(confirm)
        let notice = app.staticTexts["audioNotice"]; audioReveal(notice, app)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND (label CONTAINS[c] %@ OR value CONTAINS[c] %@)", "already saved", "already saved"), object: notice)], timeout: 10) == .completed)
        audioScreenshot(app, "Already saved recording cannot be discarded as pending")
        let pending = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch
        audioReveal(pending, app); audioPress(pending)
        XCTAssertTrue(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 12) == .completed)
        audioPress(app.buttons["audioClose"]); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 1)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch.exists)
        audioScreenshot(app, "Refused pending discard preserves one saved recording")
    }


    @MainActor func testAudioUnwrittenSaveSurvivesWorkspaceDepartureAndExplicitFinish() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, lookupLock: true, prejournal: true); audioRecord(app)
        let caption = app.textViews["audioCaption"], wording = "Keep my original workspace recording"
        audioReveal(caption, app); audioPress(caption); caption.typeText(wording)
        #if os(iOS)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        #endif
        let recovery = app.buttons["audioRetryRecovery"]
        audioReveal(recovery, app); XCTAssertTrue(recovery.exists, "The real checkpoint lock must first refuse private recovery")
        audioPress(app.buttons["audioFixtureReleaseCheckpoint"])
        let save = app.buttons["audioSave"], probe = app.staticTexts["audioFixtureLookupProbe"]
        audioReveal(save, app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", "Storage reads: 1 · locked"), object: probe)], timeout: 10), .completed)
        XCTAssertEqual(save.label, "Retry save")
        audioPress(app.buttons["audioFixtureResumeStorage"])
        audioPress(app.buttons["audioFixtureLeave"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        audioPress(app.buttons["audioFixtureOpen"])
        XCTAssertTrue(app.buttons["audioRecord"].waitForExistence(timeout: 8))
        XCTAssertFalse(app.textViews["audioCaption"].exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        audioScreenshot(app, "The foreign workspace exposes no original recording")
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.buttons["audioFixtureReturn"].waitForExistence(timeout: 8)); audioPress(app.buttons["audioFixtureReturn"])
        audioPress(app.buttons["audioFixtureOpen"])
        let pending = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-"))
        audioReveal(pending.firstMatch, app); XCTAssertEqual(pending.count, 1)
        XCTAssertTrue(pending.firstMatch.label.contains(wording))
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioDiscardPending-")).firstMatch.exists)
        XCTAssertFalse(app.buttons["audioRetryInterrupted"].exists, "Unwritten Save has one focused recovery action")
        audioScreenshot(app, "The original workspace offers one exact unwritten Save")
        audioPress(pending.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        audioReveal(caption, app); XCTAssertEqual(caption.value as? String, wording)
        XCTAssertFalse(app.buttons["audioRetryInterrupted"].exists, "Successful Finish clears the stale recovery warning")
        audioScreenshot(app, "Explicit Finish saves the original workspace recording")
        audioPress(app.buttons["audioSaveClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 1); audioPress(saved.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 12), .completed)
        audioReveal(caption, app); XCTAssertEqual(caption.value as? String, wording)
        audioScreenshot(app, "Cold return retains the finished original workspace recording")
    }

    @MainActor func testAudioUnknownSaveRetryKeepsOriginalDraftAfterLockRelease() throws { try audioUnknownSaveJourney(beforeDraft: false) }
    @MainActor func testAudioUnknownPreparedSaveRetryKeepsOriginalIDsAfterLockRelease() throws { try audioUnknownSaveJourney(beforeDraft: true) }
    @MainActor func testAudioUnknownSaveColdLaunchRecoversTheOriginalAuthorization() throws { try audioUnknownSaveJourney(beforeDraft: true, coldWhileLocked: true) }
    @MainActor private func audioUnknownSaveJourney(beforeDraft: Bool, coldWhileLocked: Bool = false) throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, beforeDraft: beforeDraft, lookupLock: true); audioRecord(app)
        let caption = app.textViews["audioCaption"], wording = "Keep this exact retry as one recording"
        audioReveal(caption, app); audioPress(caption); caption.typeText(wording)
        #if os(iOS)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        #endif
        let save = app.buttons["audioSave"], probe = app.staticTexts["audioFixtureLookupProbe"]
        func lookup(_ count: Int) {
            XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", "Storage reads: \(count) · locked"), object: probe)], timeout: 10), .completed)
            XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == true", "Retry save"), object: save)], timeout: 10), .completed)
        }
        audioReveal(save, app); audioPress(save); lookup(1)
        audioReveal(save, app); audioPress(save); lookup(2)
        #if os(iOS)
        audioReveal(caption, app, towardTop: true)
        #else
        audioReveal(caption, app)
        #endif
        XCTAssertFalse(caption.isEnabled); XCTAssertEqual(caption.value as? String, wording)
        audioScreenshot(app, "Unknown Save remains frozen after the second real-lock refusal")
        if coldWhileLocked {
            app.terminate(); audioOpen(app, reset: false)
            let pending = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-"))
            audioReveal(pending.firstMatch, app); XCTAssertEqual(pending.count, 1)
            audioPress(pending.firstMatch)
            XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 12), .completed)
            #if os(iOS)
            audioReveal(save, app, towardTop: true)
            #else
            audioReveal(save, app)
            #endif
        } else {
            audioPress(app.buttons["audioFixtureResumeStorage"])
            audioReveal(save, app); audioPress(save)
        }
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        audioScreenshot(app, "The original recording is saved after releasing the private lock")
        audioPress(app.buttons["audioSaveClose"])
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout: 8))
        app.terminate(); audioOpen(app, reset: false)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-")).firstMatch.exists)
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioRecovery-")).firstMatch.exists)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 1); audioPress(saved.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "enabled == true"), object: app.buttons["audioSaveClose"])], timeout: 12), .completed)
        #if os(iOS)
        audioReveal(caption, app, towardTop: true)
        #else
        audioReveal(caption, app)
        #endif
        XCTAssertEqual(caption.value as? String, wording)
        audioScreenshot(app, "Cold return retains one exact recording with no unfinished Save")
    }

}

extension TaskfoldUITests {
    @MainActor private func audioPrivateFiles() throws -> [URL] {
        let containers = URL(fileURLWithPath:NSHomeDirectory()).deletingLastPathComponent()
        let home = try XCTUnwrap(try FileManager.default.contentsOfDirectory(at:containers,includingPropertiesForKeys:nil).first { url in
            guard let data = try? Data(contentsOf:url.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")),
                  let info = try? PropertyListSerialization.propertyList(from:data,format:nil) as? [String:Any] else { return false }
            return info["MCMMetadataIdentifier"] as? String == "com.dbakp.taskfold.workflowteststeameditbridge"
        })
        let root = home.appendingPathComponent("Library/Application Support/TaskfoldAudioNative/AudioCommentsPrivate")
        return (FileManager.default.enumerator(at:root,includingPropertiesForKeys:nil)?.allObjects as? [URL] ?? []).filter { $0.pathExtension == "bin" }
    }
    @MainActor func testAudioBackgroundKeepsUnwrittenAuthorizationForExplicitColdFinish() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app,lookupLock:true,prejournal:true); audioRecord(app)
        let caption = app.textViews["audioCaption"], wording = "Frozen cafe\u{301} before background"
        audioReveal(caption,app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        audioReveal(app.buttons["audioRetryRecovery"],app)
        audioPress(app.buttons["audioFixtureReleaseCheckpoint"])
        let save = app.buttons["audioSave"], probe = app.staticTexts["audioFixtureLookupProbe"]
        audioReveal(save,app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:NSPredicate(format:"label == %@","Storage reads: 1 · locked"),object:probe)],timeout:10),.completed)
        XCTAssertEqual(save.label,"Retry save")
        XCTAssertFalse(try audioPrivateFiles().contains { $0.lastPathComponent.hasPrefix("save-") })
        audioPress(app.buttons["audioFixtureResumeStorage"])
        XCUIDevice.shared.press(.home)
        let journalReady = XCTNSPredicateExpectation(predicate:NSPredicate { _,_ in
            (try? self.audioPrivateFiles().filter { $0.lastPathComponent.hasPrefix("save-") }.count) == 1
        },object:nil)
        XCTAssertEqual(XCTWaiter.wait(for:[journalReady],timeout:12),.completed,"Actual departure must preserve the pre-journal authorization before process loss")
        let files = try audioPrivateFiles()
        XCTAssertFalse(files.contains { $0.lastPathComponent.hasPrefix("draft-") },"Backgrounding must not finish a draft")
        let journal = try XCTUnwrap(files.first { $0.lastPathComponent.hasPrefix("save-") })
        let payload = try XCTUnwrap(try PropertyListSerialization.propertyList(from:Data(contentsOf:journal),format:nil) as? [String:Any])
        let nextData = try XCTUnwrap(payload["next"] as? Data)
        let next = try XCTUnwrap(try PropertyListSerialization.propertyList(from:nextData,format:nil) as? [String:Any])
        XCTAssertTrue((next["caption"] as? String)?.utf8.elementsEqual(wording.utf8) == true)
        XCTAssertEqual(payload["account"] as? String,"local-audio-native")
        let attachment = XCTAttachment(data:try Data(contentsOf:journal),uniformTypeIdentifier:"com.apple.binary-property-list")
        attachment.name = "Exact synthetic Save journal kept before cold return"; attachment.lifetime = .keepAlways; add(attachment)
        app.terminate(); audioOpen(app,reset:false)
        let pending = app.buttons.matching(NSPredicate(format:"identifier BEGINSWITH %@","audioPendingSave-"))
        audioReveal(pending.firstMatch,app); XCTAssertEqual(pending.count,1)
        XCTAssertTrue(pending.firstMatch.label.contains(wording)); audioPress(pending.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:NSPredicate(format:"label == %@ AND enabled == false","Saved on this device"),object:save)],timeout:12),.completed)
        let finished = try audioPrivateFiles()
        XCTAssertFalse(finished.contains { $0.lastPathComponent.hasPrefix("save-") })
        let drafts = finished.filter { $0.lastPathComponent.hasPrefix("draft-") }; XCTAssertEqual(drafts.count,1)
        let draft = try XCTUnwrap(try PropertyListSerialization.propertyList(from:Data(contentsOf:XCTUnwrap(drafts.first)),format:nil) as? [String:Any])
        for field in ["id","revision"] { XCTAssertEqual(draft[field] as? String,next[field] as? String) }
        for field in ["audio","target","descriptor"] { XCTAssertEqual(draft[field] as? Data,next[field] as? Data) }
        XCTAssertTrue((draft["caption"] as? String)?.utf8.elementsEqual(wording.utf8) == true)
        audioScreenshot(app,"Background authorization finishes one original recording after cold return")
    }
}

extension TaskfoldUITests {
    @MainActor func testAudioRemovedPreparedSaveRequiresExplicitIndependentCopy() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        app.launchArguments = ["--uitesting", "--team-editor-testing", "--audio-comment-testing", "--audio-comment-reset", "--audio-save-lost-ack", "--audio-save-before-draft", "--audio-save-external-discard", "-appearance", "light"]
        app.launch(); app.activate(); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout:15)); audioPress(app.buttons["audioFixtureOpen"]); audioRecord(app)
        let wording = "Keep my cafe\u{301} review after another window discards Save"
        let caption = app.textViews["audioCaption"]; audioReveal(caption,app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        let save = app.buttons["audioSave"]; audioReveal(save,app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:NSPredicate(format:"label == %@","Retry save"),object:save)],timeout:12),.completed)
        let oldFile = try XCTUnwrap(try audioPrivateFiles().first { $0.lastPathComponent.hasPrefix("save-") })
        let old = try XCTUnwrap(try PropertyListSerialization.propertyList(from:Data(contentsOf:oldFile),format:nil) as? [String:Any])
        let oldNext = try XCTUnwrap(try PropertyListSerialization.propertyList(from:XCTUnwrap(old["next"] as? Data),format:nil) as? [String:Any])
        audioPress(app.buttons["audioFixtureRemovePending"])
        XCTAssertFalse(try audioPrivateFiles().contains { $0.lastPathComponent.hasPrefix("save-") || $0.lastPathComponent.hasPrefix("draft-") })
        audioReveal(save,app); audioPress(save)
        let copy = app.buttons["audioSaveCopy"]; audioReveal(copy,app); XCTAssertTrue(copy.exists); XCTAssertFalse(save.isEnabled)
        XCTAssertFalse(app.buttons["audioSaveClose"].isEnabled)
        XCTAssertTrue(app.staticTexts["audioNotice"].label.contains("removed or changed"))
        XCTAssertFalse(try audioPrivateFiles().contains { $0.lastPathComponent.hasPrefix("save-") || $0.lastPathComponent.hasPrefix("draft-") })
        audioScreenshot(app,"Removed pending Save offers an explicit independent copy")
        audioPress(app.buttons["audioClose"])
        let copyAndClose = app.buttons["Save separate draft and close"]
        XCTAssertTrue(copyAndClose.waitForExistence(timeout:5)); XCTAssertFalse(app.buttons["Save draft and close"].exists)
        audioPress(copyAndClose)
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:NSPredicate(format:"label == %@","Retry save"),object:save)],timeout:12),.completed)
        let copyFile = try XCTUnwrap(try audioPrivateFiles().first { $0.lastPathComponent.hasPrefix("save-") })
        let replacement = try XCTUnwrap(try PropertyListSerialization.propertyList(from:Data(contentsOf:copyFile),format:nil) as? [String:Any])
        let next = try XCTUnwrap(try PropertyListSerialization.propertyList(from:XCTUnwrap(replacement["next"] as? Data),format:nil) as? [String:Any])
        XCTAssertNotEqual(replacement["id"] as? String,old["id"] as? String); XCTAssertNotEqual(next["id"] as? String,oldNext["id"] as? String)
        XCTAssertTrue((next["caption"] as? String)?.utf8.elementsEqual(wording.utf8) == true)
        app.terminate(); audioOpen(app,reset:false)
        let pending = app.buttons.matching(NSPredicate(format:"identifier BEGINSWITH %@","audioPendingSave-")); audioReveal(pending.firstMatch,app)
        XCTAssertEqual(pending.count,1); audioPress(pending.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:NSPredicate(format:"label == %@ AND enabled == false","Saved on this device"),object:save)],timeout:12),.completed)
        let finals = try audioPrivateFiles(); XCTAssertFalse(finals.contains { $0.lastPathComponent.hasPrefix("save-") })
        let drafts = finals.filter { $0.lastPathComponent.hasPrefix("draft-") }; XCTAssertEqual(drafts.count,1)
        let draft = try XCTUnwrap(try PropertyListSerialization.propertyList(from:Data(contentsOf:XCTUnwrap(drafts.first)),format:nil) as? [String:Any])
        XCTAssertEqual(draft["id"] as? String,next["id"] as? String)
        XCTAssertTrue((draft["caption"] as? String)?.utf8.elementsEqual(wording.utf8) == true)
        for field in ["audio","target","descriptor"] { XCTAssertEqual(draft[field] as? Data,next[field] as? Data) }
        audioScreenshot(app,"Only the new independent recording survives cold Finish")
    }
}

extension TaskfoldUITests {
    @MainActor func testAudioExpiredReviewDiscardAndColdReturn() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        app.launchArguments = ["--uitesting", "--team-editor-testing", "--audio-comment-testing", "--audio-comment-reset", "--audio-save-lost-ack", "--audio-save-before-draft", "--audio-save-external-discard", "-appearance", "light"]
        app.launch(); app.activate(); XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout:15)); audioPress(app.buttons["audioFixtureOpen"]); audioRecord(app)
        let caption = app.textViews["audioCaption"], wording = "Discard only my cafe\u{301} review"
        audioReveal(caption,app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        let save = app.buttons["audioSave"]; audioReveal(save,app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for:[XCTNSPredicateExpectation(predicate:NSPredicate(format:"label == %@","Retry save"),object:save)],timeout:12),.completed)
        XCTAssertEqual(try audioPrivateFiles().filter { $0.lastPathComponent.hasPrefix("save-") }.count,1)
        audioPress(app.buttons["audioFixtureRemovePending"]); audioReveal(save,app); audioPress(save)
        audioReveal(app.buttons["audioSaveCopy"],app)
        XCTAssertFalse(app.buttons["audioSaveClose"].isEnabled)
        audioPress(app.buttons["audioClose"])
        let discard = app.buttons["Discard this review"]; XCTAssertTrue(discard.waitForExistence(timeout:8))
        audioScreenshot(app,"Close offers a scoped discard for the removed pending review")
        audioPress(discard)
        XCTAssertTrue(app.buttons["audioFixtureOpen"].waitForExistence(timeout:12)); XCTAssertFalse(app.textViews["audioCaption"].exists)
        XCTAssertTrue(try audioPrivateFiles().isEmpty,"Discard leaves no synthetic draft, review or pending authorization")
        app.terminate(); audioOpen(app,reset:false)
        XCTAssertTrue(try audioPrivateFiles().isEmpty)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format:"identifier BEGINSWITH %@","audioPendingSave-")).count,0)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format:"identifier BEGINSWITH %@","audioRecovery-")).count,0)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format:"identifier BEGINSWITH %@","audioSaved-")).count,0)
        audioScreenshot(app,"Discarded expired review remains absent after cold return")
    }
}

#if os(iOS)
extension TaskfoldUITests {
    @MainActor func testInterruptedRecordingFilesRequireExplicitRecoveryAndSurviveColdReturn() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, large: true, interrupted: true)
        XCTAssertTrue(try audioPrivateFiles().isEmpty, "Discovering staged files must not promote them")
        let warning = app.staticTexts["audioInterruptedWarning"]
        audioReveal(warning, app); XCTAssertTrue(warning.label.contains("kept"))
        audioScreenshot(app, "Interrupted recordings and kept incomplete-file warning at AX5")
        let primary = app.buttons["audioInterrupted-ac282000-0000-4000-8000-000000000001"]
        audioReveal(primary, app, towardTop: true); audioPress(primary)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: primary)], timeout: 12), .completed)
        let files = try audioPrivateFiles()
        XCTAssertEqual(files.count, 1)
        let savedFile = try XCTUnwrap(files.first)
        let original = try Data(contentsOf: savedFile)
        let fields = try XCTUnwrap(try PropertyListSerialization.propertyList(from: original, format: nil) as? [String: Any])
        XCTAssertEqual(fields["caption"] as? String, "Recovered workshop draft")
        XCTAssertFalse((fields["audio"] as? Data ?? Data()).isEmpty)
        let review = app.buttons["audioInterrupted-ac282000-0000-4000-8000-000000000002"]
        audioReveal(review, app); audioPress(review)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: review)], timeout: 12), .completed)
        let afterRecovery = try audioPrivateFiles()
        XCTAssertEqual(afterRecovery.count, 2)
        XCTAssertEqual(afterRecovery.filter { $0.lastPathComponent.hasPrefix("review-") }.count, 1, "Recovery must not save an unsaved review")
        XCTAssertEqual(try Data(contentsOf: savedFile), original)
        let recovered = app.buttons["audioRecovery-ac281000-0000-4000-8000-000000000002"]
        audioReveal(recovered, app); audioPress(recovered)
        let caption = app.textViews["audioCaption"]
        audioReveal(caption, app, towardTop: true)
        XCTAssertEqual(caption.value as? String, "Recovered workshop review")
        let save = app.buttons["audioSave"]
        audioReveal(save, app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        let committed = try audioPrivateFiles()
        XCTAssertEqual(committed.count, 2)
        XCTAssertTrue(committed.allSatisfy { $0.lastPathComponent.hasPrefix("draft-") })
        XCTAssertEqual(try Data(contentsOf: savedFile), original)
        let incomplete = savedFile.deletingLastPathComponent().appendingPathComponent(".write-ac282000-0000-4000-8000-000000000003")
        XCTAssertEqual(try Data(contentsOf: incomplete), Data("Synthetic incomplete recording payload".utf8))
        audioScreenshot(app, "Explicitly reviewed interrupted recording saved locally at AX5")
        app.terminate(); audioOpen(app, reset: false, large: true)
        audioReveal(warning, app); XCTAssertTrue(warning.label.contains("kept"))
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 2)
        let returnedReview = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND label CONTAINS %@", "audioSaved-", "Recovered workshop review")).firstMatch
        audioReveal(returnedReview, app); audioPress(returnedReview)
        audioReveal(caption, app, towardTop: true)
        XCTAssertEqual(caption.value as? String, "Recovered workshop review")
        XCTAssertEqual(try Data(contentsOf: savedFile), original)
        XCTAssertEqual(try Data(contentsOf: incomplete), Data("Synthetic incomplete recording payload".utf8))
        XCTAssertEqual(try audioPrivateFiles().count, 2)
        audioScreenshot(app, "Cold return keeps exact recovered review and original draft")
    }
}
#endif

#if os(iOS)
extension TaskfoldUITests {
    @MainActor func testInterruptedKeepBothReviewCancelAndJournalColdFinish() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        audioOpen(app, large: true, lostSave: true, beforeDraft: true, interruptedCopy: true)
        let original = try XCTUnwrap(try audioPrivateFiles().first), originalBytes = try Data(contentsOf: original)
        XCTAssertEqual(try audioPrivateFiles().count, 1)
        let staged = original.deletingLastPathComponent().appendingPathComponent(".write-ac282000-0000-4000-8000-000000000001")
        let stagedBytes = try Data(contentsOf: staged)
        let keep = app.buttons["audioInterruptedCopy-ac282000-0000-4000-8000-000000000001"]
        audioReveal(keep, app); audioPress(keep)
        let copyCaption = app.staticTexts["audioCopyCaption"], confirm = app.buttons["audioCopyConfirm"]
        audioReveal(copyCaption, app, formIdentifier: "audioCopyForm", navigationTitle: "Keep both")
        XCTAssertEqual(copyCaption.label, "Earlier workshop recording")
        audioScreenshot(app, "Keep both reviews full staged caption at AX5")
        audioPress(app.buttons["audioCopyCancel"])
        XCTAssertTrue(app.navigationBars["Audio draft"].waitForExistence(timeout: 8))
        XCTAssertEqual(try audioPrivateFiles().count, 1); XCTAssertEqual(try Data(contentsOf: original), originalBytes)
        XCTAssertEqual(try Data(contentsOf: staged), stagedBytes)
        audioReveal(keep, app); audioPress(keep)
        audioReveal(confirm, app, formIdentifier: "audioCopyForm", navigationTitle: "Keep both"); audioPress(confirm)
        let save = app.buttons["audioSave"]
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true AND label == %@", "Retry save"), object: save)], timeout: 15), .completed)
        let journal = try XCTUnwrap(try audioPrivateFiles().first { $0.lastPathComponent.hasPrefix("save-") })
        let fields = try XCTUnwrap(try PropertyListSerialization.propertyList(from: Data(contentsOf: journal), format: nil) as? [String: Any])
        XCTAssertEqual(fields["format"] as? String, "taskfold-audio-save-v3"); XCTAssertNotNil(fields["stage"] as? Data)
        XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try Data(contentsOf: staged), stagedBytes)
        XCTAssertEqual(try audioPrivateFiles().count, 2)
        app.terminate(); audioOpen(app, reset: false, large: true)
        let pending = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioPendingSave-"))
        audioReveal(pending.firstMatch, app); XCTAssertEqual(pending.count, 1)
        XCTAssertFalse(app.buttons["audioInterruptedCopy-ac282000-0000-4000-8000-000000000001"].exists)
        XCTAssertEqual(try audioPrivateFiles().count, 2); XCTAssertEqual(try Data(contentsOf: original), originalBytes)
        audioScreenshot(app, "Cold return retains one explicit copy Save without replacing latest version")
        audioPress(pending.firstMatch)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 15), .completed)
        let final = try audioPrivateFiles(); XCTAssertEqual(final.count, 2)
        XCTAssertTrue(final.allSatisfy { $0.lastPathComponent.hasPrefix("draft-") })
        XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertFalse(FileManager.default.fileExists(atPath: staged.path))
        let copy = try XCTUnwrap(final.first { $0 != original })
        let copyBytes = try Data(contentsOf: copy), copyFields = try XCTUnwrap(try PropertyListSerialization.propertyList(from: copyBytes, format: nil) as? [String: Any])
        let originalFields = try XCTUnwrap(try PropertyListSerialization.propertyList(from: originalBytes, format: nil) as? [String: Any])
        XCTAssertEqual(copyFields["caption"] as? String, "Earlier workshop recording")
        XCTAssertEqual(copyFields["audio"] as? Data, originalFields["audio"] as? Data)
        XCTAssertNotEqual(copyFields["id"] as? String, originalFields["id"] as? String)
        app.terminate(); audioOpen(app, reset: false, large: true)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 2)
        let returned = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND label CONTAINS %@", "audioSaved-", "Earlier workshop recording")).firstMatch
        audioReveal(returned, app); audioPress(returned)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app, towardTop: true)
        XCTAssertEqual(caption.value as? String, "Earlier workshop recording")
        XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try Data(contentsOf: copy), copyBytes)
        XCTAssertEqual(try audioPrivateFiles().count, 2)
        audioScreenshot(app, "Both exact recording versions survive explicit Finish and cold return")
    }
}
#endif

#if os(iOS)
extension TaskfoldUITests {
    @MainActor private func audioTaskHome() throws -> URL {
        let containers = URL(fileURLWithPath: NSHomeDirectory()).deletingLastPathComponent()
        return try XCTUnwrap(try FileManager.default.contentsOfDirectory(at: containers, includingPropertiesForKeys: nil).first { url in
            guard let data = try? Data(contentsOf: url.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")), let fields = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any] else { return false }
            return fields["MCMMetadataIdentifier"] as? String == "com.dbakp.taskfold.workflowteststeameditbridge"
        })
    }
    @MainActor private func audioTaskFiles() throws -> [URL] {
        let root = try audioTaskHome().appendingPathComponent("Library/Application Support/Taskfold/PrivateAudioDrafts")
            .appendingPathComponent("app-v1-" + SHA256.hash(data: Data("com.dbakp.taskfold.workflowteststeameditbridge".utf8)).map { String(format: "%02x", $0) }.joined())
        return (FileManager.default.enumerator(at: root, includingPropertiesForKeys: nil)?.allObjects as? [URL] ?? []).filter { $0.pathExtension == "bin" }
    }
    @MainActor private func audioTaskRows() throws -> Data {
        let path = try audioTaskHome().appendingPathComponent("Library/Application Support/Taskfold/ui-testing.json")
        let fields = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: path)) as? [String: Any])
        let tables = try XCTUnwrap(fields["tables"] as? [String: Any])
        return try JSONSerialization.data(withJSONObject: tables["tasks"] ?? [], options: [.sortedKeys])
    }
    @MainActor private func launchTaskAudio(_ app: XCUIApplication, reset: Bool, library: Bool = false, removed: Bool = false, exporting: Bool = false) {
        app.launchArguments = ["--uitesting", "--team-editor-testing", "--audio-task-editor-testing", "-appearance", "dark"]
        if reset { app.launchArguments += ["--team-editor-reset", "--audio-task-editor-reset"] }
        if library { app.launchArguments.append("--audio-library-testing") }
        if exporting { app.launchArguments.append("--audio-library-export-testing") }
        if removed { app.launchArguments.append("--audio-library-keep-removed-task") }
        app.launch(); let prepare = app.buttons["audioEditorPrepareLocal"]
        XCTAssertTrue(prepare.waitForExistence(timeout: 20), app.debugDescription); audioPress(prepare)
        XCTAssertTrue(app.buttons[library ? "audioEditorOpenLibrary" : "audioEditorOpenInbox"].waitForExistence(timeout: 12), app.debugDescription)
    }
    @MainActor private func openTaskAudio(_ app: XCUIApplication, project: Bool = false) {
        let opening = app.buttons[project ? "audioEditorOpenProject" : "audioEditorOpenInbox"]
        audioReveal(opening, app, formIdentifier: "audioEditorFixtureForm", navigationTitle: "Task recordings")
        audioPress(opening)
        let entry = app.buttons["openTaskAudioDrafts"]
        audioReveal(entry, app, formIdentifier: "taskEditorForm", navigationTitle: "Task details")
        XCTAssertTrue(entry.isEnabled); audioPress(entry)
        XCTAssertTrue(app.navigationBars["Audio draft"].waitForExistence(timeout: 15), app.debugDescription)
        audioReveal(app.buttons["audioRecord"], app)
    }
    @MainActor func testTaskAudioFixtureResetPreservesOtherAccountFiles() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        launchTaskAudio(app, reset: false)
        let application = "app-v1-" + SHA256.hash(data: Data("com.dbakp.taskfold.workflowteststeameditbridge".utf8)).map { String(format: "%02x", $0) }.joined()
        let root = try audioTaskHome().appendingPathComponent("Library/Application Support/Taskfold/PrivateAudioDrafts").appendingPathComponent(application)
        let accounts = root.appendingPathComponent("local-v1/AudioCommentsPrivate", isDirectory: true)
        let otherOwner = "fixture-other-account-" + UUID().uuidString.lowercased()
        let proof = accounts.appendingPathComponent(SHA256.hash(data: Data(otherOwner.utf8)).map { String(format: "%02x", $0) }.joined(), isDirectory: true)
        try FileManager.default.createDirectory(at: proof, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: proof) }
        let sentinel = proof.appendingPathComponent("other-account.bin"), bytes = Data("Keep unrelated synthetic account files".utf8)
        try bytes.write(to: sentinel)
        app.terminate(); launchTaskAudio(app, reset: true)
        XCTAssertEqual(try Data(contentsOf: sentinel), bytes)
        let own = accounts.appendingPathComponent(SHA256.hash(data: Data("ui-testing".utf8)).map { String(format: "%02x", $0) }.joined(), isDirectory: true)
        XCTAssertFalse(FileManager.default.fileExists(atPath: own.path), "Reset only removes the known synthetic owner's directory")
    }
    @MainActor func testRecordingBackupImportReviewCancelSaveAndColdReturn() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        launchTaskAudio(app, reset: true, library: true)
        let baseline = try audioTaskRows(), wording = "Imported recording proof\nKeep a separate private copy."
        openTaskAudio(app); audioRecord(app)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        let original = try XCTUnwrap(try audioTaskFiles().first), originalBytes = try Data(contentsOf: original)
        let source = try XCTUnwrap(try PropertyListSerialization.propertyList(from: originalBytes, format: nil) as? [String: Any])
        let audio = try XCTUnwrap(source["audio"] as? Data), descriptorData = try XCTUnwrap(source["descriptor"] as? Data)
        let descriptor = try JSONSerialization.jsonObject(with: descriptorData)
        let external = try JSONSerialization.data(withJSONObject: ["format": "taskfold-recording-backup-v1", "caption": wording, "descriptor": descriptor, "audio_base64": audio.base64EncodedString()], options: [.sortedKeys, .withoutEscapingSlashes])
        let directory = try audioTaskHome().appendingPathComponent("Documents")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let file = directory.appendingPathComponent("Taskfold-recording-import-proof.json")
        if FileManager.default.fileExists(atPath: file.path) {
            let previous = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: Any])
            guard previous["format"] as? String == "taskfold-recording-backup-v1", previous["caption"] as? String == wording,
                  Set(previous.keys) == ["format", "caption", "descriptor", "audio_base64"] else { XCTFail("Preserve an unrecognized fixture file"); return }
            // The generated AAC container can carry a different creation timestamp.
            // Replace only this recognized synthetic test input before baseline.
            try FileManager.default.removeItem(at: file)
        }
        try external.write(to: file, options: .atomic)
        audioPress(app.buttons["audioClose"])
        let reopen = app.buttons["openTaskAudioDrafts"]; audioReveal(reopen, app, formIdentifier: "taskEditorForm", navigationTitle: "Task details"); audioPress(reopen)
        XCTAssertTrue(app.navigationBars["Audio draft"].waitForExistence(timeout: 12))
        func chooseImport() {
            let button = app.buttons["audioImport"]; audioReveal(button, app); XCTAssertTrue(button.isEnabled); audioPress(button)
            let fileName = app.collectionViews.staticTexts["Taskfold-recording-import-proof.json"].firstMatch
            if !fileName.waitForExistence(timeout: 5) {
                let folder = app.collectionViews.staticTexts["Taskfold Team Editor Test"].firstMatch
                if folder.waitForExistence(timeout: 5), folder.isHittable { audioPress(folder) }
            }
            XCTAssertTrue(fileName.waitForExistence(timeout: 15), app.debugDescription)
            let cell = app.collectionViews.cells["Taskfold-recording-import-proof.json, json"]
            XCTAssertTrue(cell.exists, app.debugDescription)
            cell.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.15)).tap()
            XCTAssertTrue(fileName.waitForNonExistence(timeout: 15), "The real file picker must finish selecting before review")
            audioReveal(app.staticTexts["audioImportCaption"], app, formIdentifier: "audioImportForm", navigationTitle: "Import recording")
            XCTAssertEqual(app.staticTexts["audioImportCaption"].label, wording)
        }
        chooseImport(); audioScreenshot(app, "Recording import reviews the complete caption before Save")
        XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try audioTaskFiles().count, 1)
        audioPress(app.buttons["audioImportCancel"])
        XCTAssertTrue(app.navigationBars["Audio draft"].waitForExistence(timeout: 8))
        XCTAssertEqual(try Data(contentsOf: file), external); XCTAssertEqual(try audioTaskFiles().count, 1); XCTAssertEqual(try audioTaskRows(), baseline)
        audioScreenshot(app, "Cancel leaves source and existing recording untouched")
        chooseImport()
        let confirm = app.buttons["audioImportConfirm"]
        audioReveal(confirm, app, formIdentifier: "audioImportForm", navigationTitle: "Import recording"); audioPress(confirm)
        XCTAssertTrue(app.navigationBars["Audio draft"].waitForExistence(timeout: 15))
        audioReveal(save, app)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        XCTAssertEqual(try audioTaskFiles().count, 2); XCTAssertEqual(try Data(contentsOf: original), originalBytes)
        let importedURL = try XCTUnwrap(try audioTaskFiles().first { $0 != original })
        let importedBytes = try Data(contentsOf: importedURL)
        let imported = try XCTUnwrap(try PropertyListSerialization.propertyList(from: importedBytes, format: nil) as? [String: Any])
        XCTAssertEqual(imported["audio"] as? Data, audio); XCTAssertEqual(imported["caption"] as? String, wording)
        XCTAssertNotEqual(imported["id"] as? String, source["id"] as? String)
        XCTAssertEqual(try Data(contentsOf: file), external); XCTAssertEqual(try audioTaskRows(), baseline)
        audioScreenshot(app, "Imported recording saved as an independent private draft")
        app.terminate(); launchTaskAudio(app, reset: false, library: true); openTaskAudio(app)
        XCTAssertEqual(try audioTaskFiles().count, 2); XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try Data(contentsOf: importedURL), importedBytes)
        XCTAssertEqual(try Data(contentsOf: file), external); XCTAssertEqual(try audioTaskRows(), baseline)
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(rows.firstMatch, app); XCTAssertEqual(rows.count, 2)
        audioScreenshot(app, "Both saved recordings survive a cold return")
    }

    @MainActor func testRecordingBackupCancelSaveReadbackAndColdReturn() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        launchTaskAudio(app, reset: true, library: true, exporting: true)
        let initialRows = try audioTaskRows(), wording = "Portable recording proof\nKeep the audio and caption together."
        var baseline = initialRows
        let home = try audioTaskHome(), directory = home.appendingPathComponent("Documents")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let marker = directory.appendingPathComponent("Taskfold-recording-destination.txt"), markerBytes = Data("Synthetic recording backup destination.\n".utf8)
        if FileManager.default.fileExists(atPath: marker.path) { XCTAssertEqual(try Data(contentsOf: marker), markerBytes) }
        else { try markerBytes.write(to: marker, options: .atomic) }
        let file = directory.appendingPathComponent("Taskfold-recording.json")
        if FileManager.default.fileExists(atPath: file.path) {
            let previous = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: Any])
            guard previous["format"] as? String == "taskfold-recording-backup-v1", previous["caption"] as? String == wording else { XCTFail("Preserve an unrecognized destination file"); return }
            try FileManager.default.removeItem(at: file)
        }
        let receipt = home.appendingPathComponent("Library/Application Support/Taskfold/audio-recording-export-proof.json")
        if FileManager.default.fileExists(atPath: receipt.path) {
            let previous = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: receipt)) as? [String: String])
            guard previous["format"] == "taskfold-recording-backup-v1" else { XCTFail("Preserve an unrecognized export receipt"); return }
            try FileManager.default.removeItem(at: receipt)
        }
        openTaskAudio(app); audioRecord(app)
        let caption = app.textViews["audioCaption"]; audioReveal(caption, app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        let saveDraft = app.buttons["audioSave"]; audioReveal(saveDraft, app); audioPress(saveDraft)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: saveDraft)], timeout: 12), .completed)
        let original = try XCTUnwrap(try audioTaskFiles().first), originalBytes = try Data(contentsOf: original)
        let source = try XCTUnwrap(try PropertyListSerialization.propertyList(from: originalBytes, format: nil) as? [String: Any])
        let audio = try XCTUnwrap(source["audio"] as? Data), descriptor = try XCTUnwrap(source["descriptor"] as? Data)
        audioPress(app.buttons["audioClose"]); XCTAssertTrue(app.navigationBars["Task details"].waitForExistence(timeout: 8))
        audioPress(app.navigationBars["Task details"].buttons["Cancel"])
        XCTAssertEqual(try audioTaskRows(), initialRows)
        let remove = app.buttons["audioLibraryFixtureRemove"]
        audioReveal(remove, app, formIdentifier: "audioEditorFixtureForm", navigationTitle: "Task recordings"); audioPress(remove)
        let workspaceFile = home.appendingPathComponent("Library/Application Support/Taskfold/ui-testing.json")
        let removed = NSPredicate { _, _ in
            guard let data = try? Data(contentsOf: workspaceFile), let value = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
                  let tables = value["tables"] as? [String: Any], let tasks = tables["tasks"] as? [[String: Any]] else { return false }
            return !tasks.contains { $0["id"] as? String == "ac290000-0000-4000-8000-000000000001" }
        }
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: removed, object: nil)], timeout: 12), .completed)
        baseline = try audioTaskRows(); XCTAssertNotEqual(baseline, initialRows)
        XCTAssertEqual(try Data(contentsOf: original), originalBytes)
        func selectRecording() {
            if !app.staticTexts["audioLibraryCaption"].exists {
                let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioLibraryRow-")).firstMatch
                if row.waitForExistence(timeout: 3) {
                    audioReveal(row, app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings"); audioPress(row)
                }
            }
            let text = app.staticTexts["audioLibraryCaption"]
            audioReveal(text, app, towardTop: true, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
            XCTAssertEqual(text.label, wording)
        }
        func openLibrary() {
            let entry = app.buttons["audioEditorOpenLibrary"]
            XCTAssertTrue(entry.waitForExistence(timeout: 8))
            audioReveal(entry, app, formIdentifier: "audioEditorFixtureForm", navigationTitle: "Task recordings"); audioPress(entry)
            selectRecording()
        }
        func export() {
            selectRecording()
            let button = app.buttons["audioLibraryExport"]
            audioReveal(button, app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings"); audioPress(button)
            XCTAssertTrue(app.buttons["DOCPicker.actionButton"].waitForExistence(timeout: 25), app.debugDescription)
        }
        openLibrary(); audioScreenshot(app, "Recording backup candidate at largest dark text")
        export()
        let cancel = app.buttons["Cancel"].firstMatch
        if cancel.waitForExistence(timeout: 3) { audioPress(cancel) }
        else {
            let action = app.buttons["DOCPicker.actionButton"]
            XCTAssertTrue(action.exists, app.debugDescription)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = action.frame.minX - 12 - app.frame.minX, y = action.frame.midY - app.frame.minY
            origin.withOffset(CGVector(dx: x, dy: y)).press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: app.frame.height - 30)), withVelocity: .slow, thenHoldForDuration: 0.1)
        }
        XCTAssertTrue(app.buttons["DOCPicker.actionButton"].waitForNonExistence(timeout: 15))
        let status = app.staticTexts["audioLibraryExportStatus"]
        audioReveal(status, app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
        XCTAssertEqual(status.label, "Export cancelled."); XCTAssertFalse(FileManager.default.fileExists(atPath: receipt.path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: file.path))
        XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try audioTaskRows(), baseline)
        audioScreenshot(app, "Recording export cancellation preserves the private recording")
        export()
        let folder = app.collectionViews.staticTexts["Taskfold Team Editor Test"].firstMatch
        if folder.waitForExistence(timeout: 8), folder.isHittable { audioPress(folder) }
        let provider = app.otherElements.matching(NSPredicate(format: "identifier BEGINSWITH %@", "DOC.browsingRoot Source: com.apple.FileProvider.LocalStorage,")).firstMatch
        let namedRoot = app.otherElements["DOC.browsingRoot Source: com.apple.FileProvider.LocalStorage, Title: Taskfold Team Editor Test"]
        let namedToolbar = app.buttons["Taskfold Team Editor Test, Actions Menu"]
        let visibleMarker = app.collectionViews.staticTexts["Taskfold-recording-destination"].firstMatch
        guard provider.waitForExistence(timeout: 8), namedRoot.exists || namedToolbar.exists,
              visibleMarker.waitForExistence(timeout: 8) else { XCTFail("Choose only the isolated app's observed local Documents: " + app.debugDescription); return }
        audioScreenshot(app, "Recording backup uses the observed local Files destination")
        let save = app.buttons["DOCPicker.actionButton"]; XCTAssertTrue(save.isEnabled); audioPress(save)
        XCTAssertTrue(save.waitForNonExistence(timeout: 15))
        let completed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            FileManager.default.fileExists(atPath: file.path) && FileManager.default.fileExists(atPath: receipt.path)
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [completed], timeout: 15), .completed)
        let result = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: receipt)) as? [String: String])
        XCTAssertNotNil(result["request"].flatMap(UUID.init(uuidString:)))
        let url = try XCTUnwrap(result["url"].flatMap(URL.init(string:)))
        let deviceData = try XCTUnwrap(home.resolvingSymlinksInPath().path.components(separatedBy: "/data/").first) + "/data/"
        XCTAssertTrue(url.isFileURL && url.resolvingSymlinksInPath().path.hasPrefix(deviceData))
        XCTAssertEqual(url.lastPathComponent, "Taskfold-recording.json")
        let bytes = try Data(contentsOf: file); XCTAssertEqual(try Data(contentsOf: url), bytes)
        let portable = try XCTUnwrap(try JSONSerialization.jsonObject(with: bytes) as? [String: Any])
        XCTAssertEqual(Set(portable.keys), ["format", "caption", "descriptor", "audio_base64"])
        XCTAssertEqual(portable["format"] as? String, "taskfold-recording-backup-v1"); XCTAssertEqual(portable["caption"] as? String, wording)
        XCTAssertEqual((portable["audio_base64"] as? String).flatMap { Data(base64Encoded: $0) }, audio)
        let exportedDescriptor = try XCTUnwrap(portable["descriptor"] as? NSDictionary)
        XCTAssertEqual(exportedDescriptor, try JSONSerialization.jsonObject(with: descriptor) as? NSDictionary)
        XCTAssertFalse(String(decoding: bytes, as: UTF8.self).contains("ui-testing")); XCTAssertFalse(String(decoding: bytes, as: UTF8.self).contains("ac290000-0000-4000-8000-000000000001"))
        let attachment = XCTAttachment(data: bytes, uniformTypeIdentifier: "public.json"); attachment.name = "Portable recording delivered by native Files Save"; attachment.lifetime = .keepAlways; add(attachment)
        audioReveal(status, app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings"); XCTAssertEqual(status.label, "Recording backup saved.")
        audioScreenshot(app, "Native recording backup Save confirms delivery without changing source")
        XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try audioTaskRows(), baseline)
        let libraryRow = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioLibraryRow-")).firstMatch
        if !libraryRow.waitForExistence(timeout: 2) {
            audioReveal(app.buttons["audioLibraryBack"], app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings"); audioPress(app.buttons["audioLibraryBack"])
        }
        selectRecording()
        let form = app.collectionViews["audioLibraryForm"], origin = app.coordinate(withNormalizedOffset: .zero)
        for _ in 0..<3 {
            let bounds = form.frame.intersection(app.frame), x = bounds.minX + 8 - app.frame.minX
            let top = max(bounds.minY, app.navigationBars["Private recordings"].frame.maxY) + 40 - app.frame.minY
            origin.withOffset(CGVector(dx: x, dy: bounds.maxY - 60 - app.frame.minY)).press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: top)), withVelocity: .slow, thenHoldForDuration: 0.1)
        }
        XCTAssertTrue(app.buttons["audioLibraryBack"].isHittable, "Detail footer must be reached before checking feedback")
        XCTAssertFalse(status.exists, "A fresh recording selection must not inherit old export feedback")
        app.terminate(); launchTaskAudio(app, reset: false, library: true, removed: true, exporting: true)
        XCTAssertFalse(app.buttons["audioEditorOpenInbox"].exists); openLibrary()
        XCTAssertEqual(try Data(contentsOf: file), bytes); XCTAssertEqual(try Data(contentsOf: original), originalBytes); XCTAssertEqual(try audioTaskRows(), baseline)
        audioScreenshot(app, "Private recording and portable backup survive a cold return")
    }

    @MainActor func testPrivateRecordingLibrarySurvivesTaskMoveRemovalAndColdReturn() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        launchTaskAudio(app, reset: true, library: true)
        let workspaceFile = try audioTaskHome().appendingPathComponent("Library/Application Support/Taskfold/ui-testing.json")
        func waitForSavedFixture(project: String? = nil, removed: Bool = false) throws -> Data {
            let expected = NSPredicate { _, _ in
                guard let data = try? Data(contentsOf: workspaceFile),
                      let fields = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
                      let tables = fields["tables"] as? [String: Any], let tasks = tables["tasks"] as? [[String: Any]] else { return false }
                let matches = tasks.filter { $0["id"] as? String == "ac290000-0000-4000-8000-000000000001" }
                if removed { return matches.isEmpty }
                guard matches.count == 1, let row = matches.first,
                      row["task_generation"] as? String == "ac290000-0000-4000-8000-000000000004" else { return false }
                let actual = row["project_id"] as? String
                return project.map { actual == $0 } ?? (actual ?? "").isEmpty
            }
            XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: expected, object: nil)], timeout: 12), .completed, "Exact synthetic task state must reach the workspace file")
            return try audioTaskRows()
        }
        let initialRows = try waitForSavedFixture()
        openTaskAudio(app); audioRecord(app)
        let caption = app.textViews["audioCaption"], wording = "Keep the complete workshop instructions.\nReview contrast, spacing and the final handoff."
        audioReveal(caption, app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        let first = try XCTUnwrap(try audioTaskFiles().first), bytes = try Data(contentsOf: first)
        XCTAssertEqual(try audioTaskFiles().count, 1); XCTAssertEqual(try audioTaskRows(), initialRows)
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.navigationBars["Task details"].waitForExistence(timeout: 8))
        audioPress(app.navigationBars["Task details"].buttons["Cancel"])
        func selectLibraryRecording() {
            let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioLibraryRow-"))
            XCTAssertTrue(row.firstMatch.waitForExistence(timeout: 12), app.debugDescription)
            audioReveal(row.firstMatch, app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
            XCTAssertEqual(row.count, 1); audioPress(row.firstMatch)
            let fullCaption = app.staticTexts["audioLibraryCaption"]
            audioReveal(fullCaption, app, towardTop: true, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
            XCTAssertEqual(fullCaption.label, wording)
        }
        func openLibrary() {
            let entry = app.buttons["audioEditorOpenLibrary"]
            XCTAssertTrue(entry.waitForExistence(timeout: 8))
            audioReveal(entry, app, formIdentifier: "audioEditorFixtureForm", navigationTitle: "Task recordings"); audioPress(entry)
            selectLibraryRecording()
        }
        func playAndStop() {
            let play = app.buttons["audioLibraryPlay"]
            audioReveal(play, app, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
            XCTAssertEqual(play.label, "Play recording"); audioPress(play)
            XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", "Stop playback"), object: play)], timeout: 5), .completed)
            audioPress(play); XCTAssertEqual(play.label, "Play recording")
        }
        openLibrary(); playAndStop()
        XCUIDevice.shared.press(.home); app.activate()
        selectLibraryRecording(); playAndStop()
        XCTAssertFalse(app.staticTexts["audioLibraryMoved"].exists); XCTAssertFalse(app.staticTexts["audioLibraryUnavailable"].exists)
        audioScreenshot(app, "Private library shows the full saved caption and playable original recording")
        audioPress(app.buttons["audioLibraryClose"])
        let move = app.buttons["audioLibraryFixtureMove"]; XCTAssertTrue(move.waitForExistence(timeout: 8))
        audioReveal(move, app, formIdentifier: "audioEditorFixtureForm", navigationTitle: "Task recordings"); audioPress(move)
        let movedRows = try waitForSavedFixture(project: "ac290000-0000-4000-8000-000000000002"); XCTAssertNotEqual(movedRows, initialRows)
        openLibrary()
        audioReveal(app.staticTexts["audioLibraryMoved"], app, towardTop: true, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
        audioScreenshot(app, "Moved task recording stays in the account library with its original association")
        XCTAssertEqual(try Data(contentsOf: first), bytes); XCTAssertEqual(try audioTaskRows(), movedRows)
        audioPress(app.buttons["audioLibraryClose"])
        let remove = app.buttons["audioLibraryFixtureRemove"]; XCTAssertTrue(remove.waitForExistence(timeout: 8))
        audioReveal(remove, app, formIdentifier: "audioEditorFixtureForm", navigationTitle: "Task recordings"); audioPress(remove)
        let removedRows = try waitForSavedFixture(removed: true); XCTAssertNotEqual(removedRows, movedRows)
        openLibrary(); playAndStop()
        audioReveal(app.staticTexts["audioLibraryUnavailable"], app, towardTop: true, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
        audioScreenshot(app, "Private recording remains readable after its synthetic task is removed")
        app.terminate(); launchTaskAudio(app, reset: false, library: true, removed: true)
        XCTAssertFalse(app.buttons["audioEditorOpenInbox"].exists)
        openLibrary(); playAndStop()
        audioReveal(app.staticTexts["audioLibraryUnavailable"], app, towardTop: true, formIdentifier: "audioLibraryForm", navigationTitle: "Private recordings")
        audioScreenshot(app, "Cold return keeps orphan recording private without recreating the task")
        XCTAssertEqual(try audioTaskRows(), removedRows); XCTAssertEqual(try Data(contentsOf: first), bytes)
        XCTAssertEqual(try audioTaskFiles().count, 1)
        XCTAssertFalse(String(decoding: removedRows, as: UTF8.self).contains("complete workshop instructions"))
    }

    @MainActor func testTaskEditorInboxAndProjectRecordingsPersistOutsideTaskData() throws {
        try audioGuard(); let app = XCUIApplication(); defer { app.terminate() }
        launchTaskAudio(app, reset: true)
        let baseline = try audioTaskRows()
        openTaskAudio(app); audioRecord(app)
        let caption = app.textViews["audioCaption"], wording = "Private audio for the Inbox workshop"
        audioReveal(caption, app); audioPress(caption); caption.typeText(wording)
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        let save = app.buttons["audioSave"]; audioReveal(save, app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        let first = try XCTUnwrap(try audioTaskFiles().first), firstBytes = try Data(contentsOf: first)
        XCTAssertEqual(try audioTaskFiles().count, 1); XCTAssertEqual(try audioTaskRows(), baseline)
        XCTAssertFalse(String(decoding: baseline, as: UTF8.self).contains(wording))
        audioScreenshot(app, "Actual Inbox task editor saves private audio outside task data")
        app.terminate(); launchTaskAudio(app, reset: false); openTaskAudio(app)
        let saved = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "audioSaved-"))
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 1); audioPress(saved.firstMatch)
        audioReveal(caption, app, towardTop: true); XCTAssertEqual(caption.value as? String, wording)
        XCTAssertEqual(try Data(contentsOf: first), firstBytes); XCTAssertEqual(try audioTaskRows(), baseline)
        audioScreenshot(app, "Real task-bound Inbox audio survives app relaunch")
        audioPress(app.buttons["audioClose"])
        XCTAssertTrue(app.navigationBars["Task details"].waitForExistence(timeout: 8))
        audioPress(app.navigationBars["Task details"].buttons["Cancel"])
        XCTAssertTrue(app.buttons["audioEditorOpenProject"].waitForExistence(timeout: 8))
        openTaskAudio(app, project: true)
        XCTAssertFalse(saved.firstMatch.exists, "Inbox audio must not appear under another task/project")
        audioRecord(app); audioReveal(caption, app); audioPress(caption); caption.typeText("Private project workshop recording")
        if app.buttons["audioHideKeyboard"].exists { audioPress(app.buttons["audioHideKeyboard"]) }
        audioReveal(save, app); audioPress(save)
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@ AND enabled == false", "Saved on this device"), object: save)], timeout: 12), .completed)
        XCTAssertEqual(try audioTaskFiles().count, 2); XCTAssertEqual(try Data(contentsOf: first), firstBytes); XCTAssertEqual(try audioTaskRows(), baseline)
        let second = try XCTUnwrap(try audioTaskFiles().first { $0 != first }), secondBytes = try Data(contentsOf: second)
        app.terminate(); launchTaskAudio(app, reset: false); openTaskAudio(app, project: true)
        audioReveal(saved.firstMatch, app); XCTAssertEqual(saved.count, 1); audioPress(saved.firstMatch)
        audioReveal(caption, app, towardTop: true); XCTAssertEqual(caption.value as? String, "Private project workshop recording")
        XCTAssertEqual(try Data(contentsOf: first), firstBytes); XCTAssertEqual(try Data(contentsOf: second), secondBytes); XCTAssertEqual(try audioTaskRows(), baseline)
        audioScreenshot(app, "Project-bound private audio survives relaunch without exposing Inbox recording")
    }
}
#endif
