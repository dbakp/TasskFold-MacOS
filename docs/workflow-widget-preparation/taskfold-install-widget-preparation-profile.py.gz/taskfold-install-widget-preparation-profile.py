from pathlib import Path
import json,hashlib,subprocess
repo=Path('/Users/davidbakposada/.codex/workspaces/taskfold-acceptance/TaskFold-iOS');host=Path('/tmp/taskfold-prepared-undo-signed-ios-host')
files=['Taskfold/Core/Store.swift','Taskfold/TeamTemplateNativeFixture.swift']
assert all((repo/f).read_bytes()==(host/f).read_bytes() for f in files)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={f:sha(host/f) for f in files}
p=host/files[0];s=p.read_text()
needle='    @ObservationIgnored private(set) var workflowPreparedProjectionUsed = false\n'
extra='''    @ObservationIgnored private(set) var workflowSaveProfile: [String:Double] = [:]
    @ObservationIgnored private var workflowSaveProfileStamp: ContinuousClock.Instant? = nil
    private func beginWorkflowSaveProfile() {
        guard WorkflowUndoNativePeer.enabled, ProcessInfo.processInfo.arguments.contains("--workflow-commit-scale") else { return }
        workflowSaveProfile = [:]; workflowSaveProfileStamp = .now
    }
    private func markWorkflowSaveProfile(_ name: String) {
        guard let previous = workflowSaveProfileStamp else { return }
        let now = ContinuousClock.now, elapsed = previous.duration(to: now)
        workflowSaveProfile[name] = Double(elapsed.components.seconds) + Double(elapsed.components.attoseconds)/1e18
        workflowSaveProfileStamp = now
    }
    private func endWorkflowSaveProfile() { markWorkflowSaveProfile("commit.tail"); workflowSaveProfileStamp = nil }
'''
assert s.count(needle)==1;s=s.replace(needle,needle+extra,1)
def add(after,label):
 global s
 assert s.count(after)==1,(label,s.count(after))
 s=s.replace(after,after+'\n        #if DEBUG\n        markWorkflowSaveProfile("'+label+'")\n        #endif',1)
needle='''    func commit(_ changes: [Mutation], remember: Bool = true, widgetReceipt: WidgetCompletionRequest? = nil, widgetFeedback: WidgetCompletionFeedback? = nil, sharedCaptureReceipt: SharedCaptureDraft? = nil, locationResponse: LocationNotificationAction? = nil, locationImport: LocationHandoffImportReceipt? = nil, wearableReceipt: WearableMutationReceipt? = nil, localHistory: LocalActivityCreation.Preparation? = nil) -> Bool {
'''
assert s.count(needle)==1;s=s.replace(needle,needle+'        #if DEBUG\n        beginWorkflowSaveProfile(); defer { endWorkflowSaveProfile() }\n        #endif\n',1)
add('''        let preparedChanges=prepared''','commit.batchAdmission')
add('''        let widgetAccessBefore = workspaceReadRevision''','commit.normalizationAndGates')
add('''        if projectsFreshCreation {
            var projectionSource = snapshotRevision''','commit.rowValidation')
# The preceding mark is intentionally placed after loop entry and before projection use.
add('''        if let widgetReceipt { snapshot.widgetCompletion.record(widgetReceipt); snapshot.widgetCompletion.feedback = widgetFeedback }''','commit.projectionAndHistory')
add('''        if deferringPresentation {
            workflowPresentationDeferred = false; deferringPresentation = false
            refreshSnapshotPresentation(from: old)
        }''','commit.undoAndPresentation')
# Only the persistence body's own token preparation is measured.
start=s.index('    func persist(');end=s.index('    func makeInboxReview(',start)
body=s[start:end]
points=[('        }\n        try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(), withIntermediateDirectories: true)','persist.widgetPreparation'),('            let previous = FileManager.default.fileExists(atPath: cacheURL.path)\n                ? try JSONDecoder().decode(Snapshot.self, from: Data(contentsOf: cacheURL)) : Snapshot()','persist.previousDiskDecode'),('        durable = try WearableReceiptLedger.applying(previous: previous, proposed: durable, accepting: wearableReceipt, restarting: wearableGeneration)','persist.receiptStaging'),('        let data = try preparedData ?? JSONEncoder().encode(durable)','persist.encodingOrMatching'),('        } else { try data.write(to: cacheURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]) }','persist.atomicWrite'),('        } else { snapshot = try replaceCache(reset: nil) }','persist.acceptSnapshot'),('        publishWidgetSnapshot(background: backgroundWidgets)','persist.widgetQueueInput'),('        scheduleDailyBackup()','persist.backupScheduling')]
for needle,label in points:
 assert body.count(needle)==1,(label,body.count(needle))
 body=body.replace(needle,needle+'\n        #if DEBUG\n        markWorkflowSaveProfile("'+label+'")\n        #endif',1)
s=s[:start]+body+s[end:];p.write_text(s)
p=host/files[1];s=p.read_text();needle='''                "preparedProjectionUsed": .bool(store.workflowPreparedProjectionUsed),''';assert s.count(needle)==1;s=s.replace(needle,needle+'\n                "savePhaseSeconds": .object(store.workflowSaveProfile.mapValues { .number($0) }),',1);p.write_text(s)
Path('/tmp/taskfold-widget-preparation-profile-inputs.json').write_text(json.dumps({'scope':'Temporary disposable iOS host timers/extra synthetic receipt fields only; repository sources untouched.','repoCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'original':before,'instrumented':{f:sha(host/f) for f in files}},indent=2)+'\n')
